//
//  OneSky.h
//  OneSky
//
//  Created by Daniil Vorobyev on 10.05.2018.
//  Copyright © 2018 Daniil Vorobyev. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for OneSky.
FOUNDATION_EXPORT double OneSkyVersionNumber;

//! Project version string for OneSky.
FOUNDATION_EXPORT const unsigned char OneSkyVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <OneSky/PublicHeader.h>


